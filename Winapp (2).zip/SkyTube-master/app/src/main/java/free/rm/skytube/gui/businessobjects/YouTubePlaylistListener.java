package free.rm.skytube.gui.businessobjects;


import free.rm.skytube.businessobjects.YouTube.POJOs.YouTubePlaylist;

/**
 * An interface to return a YouTube Playlist
 */
public interface YouTubePlaylistListener {
	void onYouTubePlaylist(YouTubePlaylist playlist);

}
